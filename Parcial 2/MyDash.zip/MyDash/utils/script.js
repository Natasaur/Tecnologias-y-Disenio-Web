const llave = ''; //https://home.openweathermap.org/subscriptions/unauth_subscribe/onecall_30/base

let input = document.getElementById('input');
let button = document.getElementById('button');
let ciudad;
let api;
let line;
let pie;

button.addEventListener("click", (event)=>{})
